if ! echo $PATH | /bin/grep -q "/opt/c3-4" ; then
  PATH="$PATH:/opt/c3-4/"
fi
