#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include "log.h"
#include "fifo.h"
#include "udp-sender.h"
#include "udpcast.h"

#define BLOCKSIZE 4096

#ifdef O_BINARY
#include <io.h>
#define HAVE_O_BINARY
#endif

#ifndef O_BINARY
# define O_BINARY 0
#endif

int openFile(struct disk_config *config)
{
    if(config->fileName != NULL) {
	int in = open(config->fileName, O_RDONLY | O_BINARY, 0);
	if (in < 0) {
	    extern int errno;
	    udpc_fatal(1, "Could not open file %s: %s\n", config->fileName,
		       strerror(errno));
	}
	return in;
    } else {
	return 0;
    }
}


int openPipe(struct disk_config *config, int in, int *pidp)
{
    /**
     * Open the pipe
     */
    *pidp=0;
    if(config->pipeName != NULL) {
	/* pipe */
	char *arg[256];
	int filedes[2];

	parseCommand(config->pipeName, arg);

	if(pipe(filedes) < 0) {
	    perror("pipe");
	    exit(1);
	}
#ifdef HAVE_O_BINARY
	setmode(filedes[0], O_BINARY);
	setmode(filedes[1], O_BINARY);
#endif
	switch((*pidp=fork())) {
	    case 0: /* child */
		if(in != 0) {
		    close(0);
		    dup(in);
		}
		close(filedes[0]);
		close(1);
		dup(filedes[1]);
		close(filedes[1]);
		execvp(arg[0], arg);
		perror("exec");
		fprintf(stderr,"Could not execute \"%s\": %s\n", 
			config->pipeName, strerror(errno));
	    case -1: /* error */
		perror("pipe fork");
		break;
	    default:
		/* parent, continue */
		break;
	}
	close(filedes[1]);
	in = filedes[0];
    }
    return in;
}

/**
 * This file is reponsible for reading the data to be sent from disk
 */
int localReader(struct disk_config *config, struct fifo *fifo, int in)
{
    while(1) {
	int pos = pc_getConsumerPosition(fifo->freeMemQueue);
	int bytes = 
	    pc_consumeContiguousMinAmount(fifo->freeMemQueue, BLOCKSIZE);
	if(bytes > (pos + bytes) % BLOCKSIZE)
	    bytes -= (pos + bytes) % BLOCKSIZE;

	bytes = read(in, fifo->dataBuffer + pos, bytes);
	if(bytes < 0) {
	    perror("read");
	    exit(1);
	}

	if (bytes == 0) {
	    /* the end */
	    pc_produceEnd(fifo->data);
	    break;
	} else {
	    pc_consumed(fifo->freeMemQueue, bytes);
	    pc_produce(fifo->data, bytes);
	}
    }
    return 0;
}
