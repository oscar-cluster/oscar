#include "udpc_version.h"

char *version="2003-08-31";
