use constant ERROR      => -1;
use constant SUCCESS    => 0;

1;